class Main {
  public static void main(String[] args) {
    Fila f = new Fila();
    Atleta a1 = new Atleta("Joao", "volei", "nike", 167, 55);
    Atleta a2 = new Atleta("Sophia", "volei", "adidas", 155, 48);
    Atleta a3 = new Atleta("luiza", "futebol", "jordan", 160, 80);

    f.inserir(new No(a1));
    f.inserir(new No(a2));
    f.inserir(new No(a3));
    f.imprime();
    System.out.println("============");
    f.remover();
    f.inserir(new No(a1));
    f.imprime();
    
  }
}