public class Pilha{
  No inicio;
  No fim;

  public void inserir(No insere){
    if(inicio==null){
      inicio=insere;
      fim=insere;
    }
    else{
      fim.proximo=insere;
      fim=insere;
    }
  }

  public void remover(){
    if(inicio==null){
      System.out.println("Lista vazia");
    }
    else{
      No aux=inicio;
      while(aux!=null){
        System.out.println("a");
        if(aux.proximo==fim){
          fim=aux;
          fim.proximo=null;
          break;
        }
        aux = aux.proximo;
      }
    }
  }

  public void imprime(){
    No aux=inicio;
    while(aux!=null){
      System.out.println(aux.toString());
      aux = aux.proximo;
    }
  }
}